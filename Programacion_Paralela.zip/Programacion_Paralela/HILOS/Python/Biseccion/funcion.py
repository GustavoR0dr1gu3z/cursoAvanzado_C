from numpy import linspace, sin, cos, pi, exp
f = lambda x: exp(-x)-x
f0 = lambda x: pow(x,4)-10*pow(x,3)+35*x**2-50*x+24
fp = lambda x: 12*x**2-30*x+4

