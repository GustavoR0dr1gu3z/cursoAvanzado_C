float* lee_vec(char*, int);
float* crea_vec(int);
int muestra_vec(float*, int);