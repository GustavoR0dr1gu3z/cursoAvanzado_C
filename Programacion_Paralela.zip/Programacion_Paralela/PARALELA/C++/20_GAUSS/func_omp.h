float** crea_mat(int, int);
float* crea_vec(int);
int muestra_mat(float**, int, int);
int muestra_vec(float*, int);
void* mult_hilo(void*);
float prod_mm(float**, float**, int);
float** lee_mat(char* ,int ,int);
float* lee_vec(char*, int);
int ini_vect(float*,int);
float *gauss_f(float**, int , int );

